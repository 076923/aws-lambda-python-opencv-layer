opencv_version = "4.5.5.62"
contrib = False
headless = True
ci_build = True